/*! the start class */

public class Start 
{
	/*!
	* start the OsuMenu
	*/
	public static void main(String[] args) 
	{
		OsuMenu menu = new OsuMenu();
		menu.setResizable(false);
	}
}
